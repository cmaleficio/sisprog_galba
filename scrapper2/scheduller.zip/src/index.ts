require('dotenv').config()
const cron = require("node-cron");
import express from 'express';
import path from 'path';
import { makeDatabaseBackup } from './backup';

import { isDatabaseConnected } from './database';
// importing routes
import IndexRoutes from './routes';

// Initializations
const app = express();
// import './database' 


// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: false }));


// Statics
app.use(express.static(path.join(__dirname, 'public')));
// Starting server


// cron

cron.schedule("*/60 * * * * *", async function () {
   console.log("---------------------");
   const hasConexionWithDatabase = await isDatabaseConnected()
   console.log(`la base de datos esta conectada ? ${hasConexionWithDatabase}`)
   if (hasConexionWithDatabase) {
      console.log(`La base de datos esta conectada, hare el backup`)
      await makeDatabaseBackup()
   } else {
      console.log(`He tenido algun problema a la hora de conectarme a la base de datos`)
   }
   console.log("running a task every 15 seconds");
   console.log("---------------------");
});
