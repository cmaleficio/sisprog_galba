import {Router} from 'express';
import cors from 'cors';
// imports

import corsOptions from '../configs/corsOptions';


const router: Router = Router();



export default router;