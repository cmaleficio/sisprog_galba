export const mongodb = {
    "URI": "mongodb://mongo:27017/main"
}